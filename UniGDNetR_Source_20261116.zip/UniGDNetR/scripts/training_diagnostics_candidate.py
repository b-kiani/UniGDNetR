"""Opt-in training/validation diagnostics; never imported by the baseline notebook.

No checkpoint loading, training, data discovery, or file writes occur on import.
Changing loss precision requires a separate experiment identity and validation.
"""
import torch
import torch.nn.functional as F


def fp32_soft_dice_candidate(logits, target, eps=1e-6):
    """Original foreground/present-class objective with explicit FP32 reductions."""
    classes = logits.shape[1]
    if target.dtype != torch.long or target.shape != logits.shape[:1] + logits.shape[2:]:
        raise ValueError("Target must be long with shape [batch, height, width].")
    if target.numel() == 0 or target.min() < 0 or target.max() >= classes:
        raise ValueError("Target labels must be inside the task head label range.")
    probabilities = torch.softmax(logits.float(), dim=1)[:, 1:]
    onehot = F.one_hot(target, classes).permute(0, 3, 1, 2).float()[:, 1:]
    axes = (0, 2, 3)
    intersection = (probabilities * onehot).sum(axes, dtype=torch.float32)
    truth_count = onehot.sum(axes, dtype=torch.float32)
    denominator = probabilities.sum(axes, dtype=torch.float32) + truth_count
    dice = (2 * intersection + eps) / (denominator + eps)
    present = truth_count > 0
    return 1 - (dice[present].mean() if present.any() else dice.mean())


@torch.no_grad()
def class_counts(logits, target):
    """Return aggregate counts only; retain no images, IDs, or voxel predictions.

    Apply on training/validation batches only during diagnosis. Pool counts across
    batches before computing pooled Dice; keep existing batch-mean Dice separately.
    Rows are ground-truth classes and columns are predicted classes.
    """
    classes = logits.shape[1]
    if target.dtype != torch.long or target.shape != logits.shape[:1] + logits.shape[2:]:
        raise ValueError("Target must match logits and use integer class labels.")
    if target.numel() == 0 or target.min() < 0 or target.max() >= classes:
        raise ValueError("Target labels outside the task head label range.")
    if not torch.isfinite(logits).all():
        raise ValueError("Non-finite logits.")
    prediction = logits.argmax(1)
    matrix = torch.bincount((target * classes + prediction).reshape(-1),
                            minlength=classes * classes).reshape(classes, classes)
    return matrix.cpu()


def summarise_counts(matrix):
    """Per-class failure counts and denominators; both-empty Dice remains None."""
    matrix = torch.as_tensor(matrix)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Expected a square confusion matrix.")
    if not torch.isfinite(matrix).all() or (matrix < 0).any() or (matrix != matrix.round()).any():
        raise ValueError("Counts must be finite nonnegative integers.")
    truth = matrix.sum(1)
    prediction = matrix.sum(0)
    rows = []
    for cls in range(1, matrix.shape[0]):
        gt, pred, tp = int(truth[cls]), int(prediction[cls]), int(matrix[cls, cls])
        rows.append({"class": cls, "truth_voxels": gt, "predicted_voxels": pred,
                     "true_positive": tp, "false_positive": pred-tp,
                     "false_negative": gt-tp,
                     "dice": 2*tp/(gt+pred) if gt+pred else None,
                     "sensitivity": tp/gt if gt else None,
                     "precision": tp/pred if pred else None})
    return rows
