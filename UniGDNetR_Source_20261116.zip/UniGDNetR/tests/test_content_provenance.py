import dataclasses
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('provenance', ROOT/'scripts/content_provenance.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)

class ProvenanceTests(unittest.TestCase):
    def test_timestamp_and_mount_relocation_do_not_change_content_identity(self):
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'mount-a';b=Path(td)/'mount-b';a.mkdir();b.mkdir()
            (a/'scan').write_bytes(b'fixed content');shutil.copy(a/'scan',b/'scan')
            os.utime(b/'scan',ns=(1_000_000_000,2_000_000_000))
            x=p.ContentProvenance({'dataset-v1':a});y=p.ContentProvenance({'dataset-v1':b})
            self.assertEqual(x.signature(a/'scan'),y.signature(b/'scan'))
            (b/'scan').write_bytes(b'other content')
            y=p.ContentProvenance({'dataset-v1':b});y.signature(b/'scan')
            with self.assertRaises(RuntimeError):p.verify_content_baseline(y.manifest(),x.manifest())
    def test_exact_artifact_guard_rejects_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);f=root/'checkpoint';f.write_bytes(b'original')
            evidence={'checkpoint':{'bytes':8,'sha256':p.sha256_file(f)}}
            p.verify_artifacts(root,evidence);f.write_bytes(b'corrupt!')
            with self.assertRaises(RuntimeError):p.verify_artifacts(root,evidence)
    def test_unrecognized_root_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(RuntimeError):p.ContentProvenance({'data':Path(td)/'data'}).signature(Path(td)/'outside')
    def test_explicit_migration_keeps_checkpoint_bytes_and_restricts_alias(self):
        with tempfile.TemporaryDirectory() as td:
            prior=Path(td)/'prior';out=Path(td)/'output'
            for d in ['manifests','slice_indices','checkpoints']:(prior/d).mkdir(parents=True)
            checkpoint=prior/'checkpoints/model.pt';checkpoint.write_bytes(b'original model state')
            index=prior/'slice_indices/task_train_old.csv';index.write_text('case_id,group_id,z,positive,labels\n1,1,0,1,{}\n')
            config={}; prepared={'pipeline_revision':'v7','dataset_fingerprint':'old','config':config,
                'index_files':['/kaggle/working/UniGDNetR/slice_indices/'+index.name]}
            (prior/'manifests/unigdnetr_prepared.json').write_text(json.dumps(prepared))
            files={str(f.relative_to(prior)):{'bytes':f.stat().st_size,'sha256':p.sha256_file(f)} for f in prior.rglob('*') if f.is_file()}
            baseline={'legacy_combined_fingerprint':'old','files':files,'source_notebook_version':'369935019','source_versions':{'data':1}}
            shutil.copytree(prior,out)
            @dataclasses.dataclass
            class Config: pass
            provenance=p.ContentProvenance({'data':prior})
            g={'__builtins__':__builtins__,'Path':Path,'json':json,'hashlib':hashlib,'shutil':shutil,
               'RECOVERY_BASELINE':baseline,'resume_root':prior,'OUTPUT_ROOT':out,'CFG':Config(),
               'asdict':dataclasses.asdict,'PIPELINE_REVISION':'v7','splits':{'task':{'train':[{'case_id':'1'}]}},
               'DATASET_FINGERPRINT':'new','TASK_DATASET_FINGERPRINTS':{'task':'new-task'},
               'records_fingerprint':lambda _: 'new-index-fingerprint','CONTENT_PROVENANCE':provenance,
               'verify_artifacts':p.verify_artifacts,'verify_content_baseline':p.verify_content_baseline}
            exec((ROOT/'scripts/recovery_runtime.py').read_text(),g)
            self.assertEqual(checkpoint.read_bytes(),(out/'checkpoints/model.pt').read_bytes())
            self.assertEqual(json.loads((out/'manifests/unigdnetr_prepared.json').read_text())['dataset_fingerprint'],'new')
            self.assertEqual(json.loads((out/'manifests/legacy_v2_prepared_original.json').read_text()),prepared)
            fn=g['legacy_checkpoint_verified'];sha=files['checkpoints/model.pt']['sha256']
            self.assertTrue(fn({'dataset_fingerprint':'old','_verified_source_sha256':sha}))
            self.assertFalse(fn({'dataset_fingerprint':'old','_verified_source_sha256':'untrusted'}))
            self.assertFalse(fn({'dataset_fingerprint':'other','_verified_source_sha256':sha}))

if __name__=='__main__': unittest.main()
