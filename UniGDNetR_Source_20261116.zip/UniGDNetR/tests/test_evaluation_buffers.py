import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('buffers', ROOT/'scripts/evaluation_buffers.py')
buffers = importlib.util.module_from_spec(spec); spec.loader.exec_module(buffers)

class EvaluationBuffersTest(unittest.TestCase):
    def test_batches_match_original_stack_and_cleanup(self):
        rng = np.random.default_rng(18)
        values = rng.random((7, 5, 9, 11), dtype=np.float32)
        values /= values.sum(axis=1, keepdims=True)
        entropy = -(values*np.log(values)).sum(axis=1)
        with tempfile.TemporaryDirectory() as root:
            store = buffers.DiskPrediction(5, (9, 11, 7), root)
            path = Path(store.temp.name)
            store.write(0, values[:2], entropy[:2]);store.write(2, values[2:], entropy[2:])
            with store:
                original = np.stack(list(values), axis=-1)
                np.testing.assert_array_equal(store.probs, original)
                np.testing.assert_array_equal(store.entropy, np.stack(list(entropy), axis=-1))
                np.testing.assert_array_equal(store.pred, original.argmax(0).astype(np.int16))
                self.assertIsInstance(store.probs, np.memmap)
            self.assertFalse(path.exists())

    def test_chunked_ece_matches_original_with_and_without_sampling(self):
        notebook=json.loads((ROOT/'notebooks/03_UniGDNetR_EVALUATE_original.ipynb').read_text())
        source=''.join(notebook['cells'][27]['source'])
        start=source.index('def ece_score(');end=source.index('\ndef task_regions', start)
        namespace={'np':np};exec(source[start:end], namespace)
        rng=np.random.default_rng(7)
        for shape in [(7,8,9),(65,66,67)]:
            p=rng.random((3,*shape),dtype=np.float32);p/=p.sum(0,keepdims=True)
            gt=rng.integers(0,3,size=shape,dtype=np.int16)
            expected=namespace['ece_score'](p,gt)
            for chunk in [17,32768]:
                self.assertAlmostEqual(buffers.chunked_ece(p,gt,chunk_voxels=chunk),expected,places=6)

    def test_incomplete_duplicate_and_invalid_batches_rejected(self):
        store=buffers.DiskPrediction(2,(3,4,2))
        try:
            with self.assertRaises(RuntimeError):store.require_complete()
            p=np.ones((1,2,3,4),dtype=np.float32)*.5;e=np.ones((1,3,4),dtype=np.float32)
            store.write(0,p,e)
            with self.assertRaises(ValueError):store.write(0,p,e)
            with self.assertRaises(ValueError):store.write(2,p,e)
        finally:store.close()

if __name__=='__main__':unittest.main()
