import ast
import json
import math
import os
from collections import OrderedDict
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
from typing import *
import nibabel as nib
from nibabel.processing import resample_from_to
import numpy as np
import psutil
ROOT=Path(__file__).resolve().parents[1]

class CandidateTests(unittest.TestCase):
    def test_candidate_parses_and_refuses_unapproved_execution(self):
        n=json.loads((ROOT/'notebooks/UniGDNetR_Kaggle_Evaluation_CANDIDATE.ipynb').read_text())
        for c in n['cells']:
            if c['cell_type']=='code':ast.parse(''.join(c['source']))
        with patch.dict(os.environ, {'UNIGDNETR_EVALUATION_PORT_APPROVED':'0'}):
            with self.assertRaisesRegex(RuntimeError,'not yet validated'):
                exec(''.join(n['cells'][1]['source']),{})
        source='\n'.join(''.join(c['source']) for c in n['cells'])
        self.assertIn('REQUIRE_ALL_CHECKPOINTS = True',source)
        self.assertIn('require_complete=True',source)
        self.assertNotIn('FULL AUTOMATIC TRAINING ENABLED',source)

    def test_ram_fixed_geometry_and_normalisation_match_original(self):
        notebooks=[json.loads((ROOT/'notebooks'/name).read_text()) for name in
                   ['03_UniGDNetR_EVALUATE_original.ipynb','02_UniGDNetR_TRAIN_RAM_Fixed.ipynb']]
        spaces=[]
        for nb in notebooks:
            namespace=dict(globals())
            namespace['PIPELINE_REVISION']='synthetic-test'
            namespace['TASK_SPECS']={'lits':{'classes':3}}
            namespace['CFG']=SimpleNamespace(cache_cases=2,cache_max_bytes=2*1024**3)
            source=''.join(nb['cells'][17]['source']).split('def file_signature(')[0]
            exec(source,namespace);spaces.append(namespace)
        with tempfile.TemporaryDirectory() as root:
            p=Path(root);rng=np.random.default_rng(42)
            affine=np.diag([-1.,1.,2.,1.]);affine[0,3]=5
            image=(rng.normal(size=(6,7,5))*180).astype(np.float32)
            mask=np.zeros((3,7,5),dtype=np.float32);mask[1:,2:5,1:4]=2
            mask_affine=affine.copy();mask_affine[0,0]=-2
            nib.save(nib.Nifti1Image(image,affine),p/'image.nii')
            nib.save(nib.Nifti1Image(mask,mask_affine),p/'mask.nii')
            record={'images':[str(p/'image.nii')],'mask':str(p/'mask.nii'),'case_id':'synthetic','task':'lits'}
            original=spaces[0]['load_case'](record)
            bounded=spaces[1]['load_case'](record)
            np.testing.assert_allclose(original[0],bounded[0],atol=1e-7,rtol=0)
            np.testing.assert_array_equal(original[1],bounded[1])
            self.assertEqual(set(np.unique(bounded[1])),{0,2})

    def test_original_absence_conventions_and_spacing_preserved(self):
        original=json.loads((ROOT/'notebooks/03_UniGDNetR_EVALUATE_original.ipynb').read_text())
        candidate=json.loads((ROOT/'notebooks/UniGDNetR_Kaggle_Evaluation_CANDIDATE.ipynb').read_text())
        functions={}
        for label,nb in [('original',original),('candidate',candidate)]:
            nodes={}
            for cell in nb['cells']:
                if cell['cell_type']=='code':
                    for node in ast.parse(''.join(cell['source'])).body:
                        if isinstance(node,ast.FunctionDef) and node.name in ['binary_metrics','hd95_binary']:
                            nodes[node.name]=node
            functions[label]=nodes
        namespace={'np':np,'ndi':__import__('scipy.ndimage',fromlist=['ndimage'])}
        for name,node in functions['original'].items():
            self.assertEqual(ast.dump(node),ast.dump(functions['candidate'][name]))
            exec(compile(ast.Module(body=[node],type_ignores=[]),'metrics','exec'),namespace)
        empty=np.zeros((4,4,4),dtype=bool);one=empty.copy();one[1,2,2]=True
        self.assertTrue(np.isnan(namespace['binary_metrics'](empty,empty)['dice']))
        self.assertEqual(namespace['binary_metrics'](empty,one)['dice'],0)
        self.assertTrue(np.isnan(namespace['hd95_binary'](empty,one)))
        shifted=empty.copy();shifted[2,2,2]=True
        self.assertEqual(namespace['hd95_binary'](shifted,one,(2,1,1)),2)

if __name__=='__main__':unittest.main()
