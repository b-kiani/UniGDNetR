import importlib.util
import json
import random
import tempfile
from pathlib import Path
import unittest
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('case_cache',ROOT/'scripts/evaluation_case_cache.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def state():return {'python':random.getstate(),'numpy':np.random.get_state(),'torch':np.array([2,4,6],dtype=np.uint8),'cuda':None}
def restore(payload):
    s=m.unpack_rng(payload,lambda raw:np.frombuffer(raw,dtype=np.uint8).copy())
    random.setstate(s['python']);np.random.set_state(s['numpy'])
class CaseCacheTests(unittest.TestCase):
    def test_interrupted_resume_matches_uninterrupted_random_stream(self):
        initial_python=random.getstate();initial_numpy=np.random.get_state()
        try:
            with tempfile.TemporaryDirectory() as root:
                cache=m.CaseResultCache(root,'checkpoint-content-and-scenario')
                random.seed(13);np.random.seed(13)
                expected=[]
                for i in range(4):
                    before=m.pack_rng(state());rows=[{'case':i,'score':random.random()+np.random.random(),'absent':float('nan')}]
                    expected.append(rows[0]['score'])
                    if i<2:cache.put(str(i),before,m.pack_rng(state()),rows)
                # Fresh process state plus two cached cases; continue remaining work.
                random.seed(13);np.random.seed(13);observed=[]
                for i in range(4):
                    hit=cache.get(str(i),m.pack_rng(state()))
                    if hit:
                        rows,post=hit;restore(post);self.assertTrue(np.isnan(rows[0]['absent']))
                    else:rows=[{'score':random.random()+np.random.random()}]
                    observed.append(rows[0]['score'])
                self.assertEqual(observed,expected)
        finally:random.setstate(initial_python);np.random.set_state(initial_numpy)

    def test_corruption_wrong_rng_and_changed_context_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            cache=m.CaseResultCache(root,'job-a');before=m.pack_rng(state())
            cache.put('case/../safe',before,before,[{'dice':.5}])
            self.assertEqual(cache.path('case/../safe').parent,Path(root))
            different=dict(before);different['torch']='AAAA'
            with self.assertRaisesRegex(ValueError,'RNG chain'):cache.get('case/../safe',different)
            self.assertIsNone(m.CaseResultCache(root,'job-b').get('case/../safe',before))
            p=cache.path('case/../safe');data=json.loads(p.read_text());data['payload']['rows'][0]['dice']=.9;p.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError,'Corrupted'):cache.get('case/../safe',before)
if __name__=='__main__':unittest.main()
