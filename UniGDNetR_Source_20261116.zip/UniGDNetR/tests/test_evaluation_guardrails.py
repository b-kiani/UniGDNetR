import importlib.util
from pathlib import Path
import copy
import unittest
from unittest.mock import patch
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1]
def load(name):
    spec=importlib.util.spec_from_file_location(name, ROOT/'scripts'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
g=load('evaluation_guardrails');buffers=load('evaluation_buffers')
SPECS={'brats':{'class_names':['BG','NETC','SNFH','ET','RC']},'lits':{'class_names':['BG','liver','tumour']},'acdc':{'class_names':['BG','RV','MYO','LV']}}
EXPERIMENTS={name:{'selected_tasks':None} for name in ['UniGDNetR','Uniform-slice','Shared-no-FiLM','No-boundary']}
EXPERIMENTS.update({f'SingleTask-{task}':{'selected_tasks':[task]} for task in SPECS})
def record(case,patient):return {'case_id':case,'patient_id':patient}
def fixture():
    return {task:{name:[record(task+'-'+name,task+'-'+name+'-patient')] for name in ['train','val','test']} for task in SPECS}
def rows_for(splits):
    return [dict(zip(['experiment','seed','task','case_id','patient_id','region'],key),
                 corruption='clean',severity=0,missing_modalities='[]',gt_voxels=2,pred_voxels=2,
                 dice=.5,iou=1/3,sensitivity=.5,precision=.5,ece=.1,hd95=1)
            for key in sorted(g.expected_clean_keys(splits,EXPERIMENTS,[13,37,71],SPECS))]
class CoverageTests(unittest.TestCase):
    def test_complete_matrix_and_patient_counts(self):
        splits=fixture();rows=rows_for(splits)
        receipt=g.validate_clean_coverage(rows,splits,EXPERIMENTS,[13,37,71],SPECS)
        self.assertEqual(receipt['observed_rows'],165)
        # Expected matrix for the current held-out cohorts, not invented measurements.
        for task,(scans,patients) in {'brats':(187,170),'lits':(20,20),'acdc':(30,15)}.items():
            splits[task]['test']=[record(f'{task}-test-{i}',f'{task}-test-patient-{i%patients}') for i in range(scans)]
        self.assertEqual(len(g.expected_clean_keys(splits,EXPERIMENTS,[13,37,71],SPECS)),18780)

    def test_missing_duplicate_wrong_patient_scenario_seed_and_nonfinite_rejected(self):
        splits=fixture();rows=rows_for(splits)
        changes=[('patient_id','unknown'),('seed',999),('corruption','blur'),('missing_modalities','[0]'),('ece',float('nan')),('dice',float('inf')),('hd95',-1)]
        for field,value in changes:
            changed=copy.deepcopy(rows);changed[0][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):g.validate_clean_coverage(changed,splits,EXPERIMENTS,[13,37,71],SPECS)
        for changed in [rows[:-1],rows+[rows[0]]]:
            with self.assertRaises(ValueError):g.validate_clean_coverage(changed,splits,EXPERIMENTS,[13,37,71],SPECS)

    def test_longitudinal_patient_leak_rejected_even_with_different_case_ids(self):
        splits=fixture();splits['brats']['test'][0]['patient_id']=splits['brats']['train'][0]['patient_id']
        with self.assertRaisesRegex(ValueError,'leakage'):g.validate_splits(splits)

    def test_empty_class_conventions_are_retained_and_counted(self):
        splits=fixture();rows=rows_for(splits);row=rows[0]
        row.update(gt_voxels=0,pred_voxels=0,dice=float('nan'),iou=float('nan'),sensitivity=float('nan'),precision=float('nan'),hd95=float('nan'))
        receipt=g.validate_clean_coverage(rows,splits,EXPERIMENTS,[13,37,71],SPECS)
        self.assertEqual(receipt['absence_counts']['both_empty'],1)
        row['dice']=1
        with self.assertRaisesRegex(ValueError,'absence convention'):g.validate_clean_coverage(rows,splits,EXPERIMENTS,[13,37,71],SPECS)

    def test_insufficient_disk_rejected_before_volume_buffers_created(self):
        with patch.object(buffers.shutil,'disk_usage',return_value=SimpleNamespace(free=0)):
            with self.assertRaisesRegex(OSError,'Insufficient free disk'):buffers.DiskPrediction(5,(5,6,7))

if __name__=='__main__':unittest.main()
