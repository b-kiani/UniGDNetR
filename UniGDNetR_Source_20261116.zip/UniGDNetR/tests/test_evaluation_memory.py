import ast
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import weakref
import numpy as np
from scipy import ndimage as ndi
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('memory',ROOT/'scripts/evaluation_memory.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
n=json.loads((ROOT/'notebooks/03_UniGDNetR_EVALUATE_original.ipynb').read_text());s=''.join(n['cells'][27]['source']);namespace={'np':np,'ndi':ndi,'TASK_SPECS':{'lits':{'class_names':['BG','Liver','Tumour']},'acdc':{'class_names':['BG','RV','MYO','LV']}}}
for task in namespace['TASK_SPECS']:namespace['TASK_SPECS'][task]['classes']=len(namespace['TASK_SPECS'][task]['class_names'])
for node in ast.parse(s).body:
    if isinstance(node,ast.FunctionDef) and node.name in ('hd95_binary','task_regions'):exec(compile(ast.Module(body=[node],type_ignores=[]),'original','exec'),namespace)
class MemoryTests(unittest.TestCase):
    def test_exact_hd95_for_sparse_dense_edges_holes_and_anisotropy(self):
        rng=np.random.default_rng(19)
        for shape in [(3,4,5),(9,8,7),(15,13,11)]:
            for probability in [.03,.5,.98]:
                for spacing in [(1,1,1),(.6,.8,4.2)]:
                    a=rng.random(shape)<probability;b=rng.random(shape)<probability
                    expected=namespace['hd95_binary'](a,b,spacing)
                    actual=m.hd95_cropped_sequential(a,b,spacing)
                    if np.isnan(expected):self.assertTrue(np.isnan(actual))
                    else:self.assertEqual(actual,expected)
        empty=np.zeros((12,13,14),bool);a=empty.copy();b=empty.copy();a[0,0,0]=1;b[-1,-1,-1]=1
        self.assertEqual(m.hd95_cropped_sequential(a,b,(2,3,4)),namespace['hd95_binary'](a,b,(2,3,4)))
        self.assertTrue(np.isnan(m.hd95_cropped_sequential(a,empty)))
        a[:]=True;b[:]=True;b[3:7,3:7,3:7]=False
        self.assertEqual(m.hd95_cropped_sequential(a,b),namespace['hd95_binary'](a,b))

    def test_regions_match_original_all_labels_without_retaining_region_dict(self):
        rng=np.random.default_rng(2)
        for task,classes in [('brats',5),('lits',3),('acdc',4)]:
            a=rng.integers(0,classes,(8,9,7));b=rng.integers(0,classes,a.shape)
            expected=namespace['task_regions'](task,a,b)
            generator=m.iter_task_regions(task,a,b,namespace['TASK_SPECS'])
            self.assertFalse(isinstance(generator,dict))
            for name,(pred,gt) in generator:
                np.testing.assert_array_equal(pred,expected[name][0]);np.testing.assert_array_equal(gt,expected[name][1])

    def test_only_one_distance_field_is_retained_and_crop_contains_foreground(self):
        a=np.zeros((64,64,64),bool);b=a.copy();a[20:30,21:31,22:32]=1;b[22:32,23:33,24:34]=1
        reference=ndi.distance_transform_edt;previous=[];shapes=[]
        def tracked(values,*args,**kwargs):
            if previous:self.assertIsNone(previous[-1]())
            result=reference(values,*args,**kwargs);previous.append(weakref.ref(result));shapes.append(values.shape);return result
        with patch.object(m.ndi,'distance_transform_edt',tracked):m.hd95_cropped_sequential(a,b)
        self.assertEqual(shapes,[(14,14,14),(14,14,14)])
    def test_header_only_affine_matches_original_canonical_orientation(self):
        import math
        import tempfile
        import nibabel as nib
        from functools import lru_cache
        notebook=json.loads((ROOT/'notebooks/UniGDNetR_Kaggle_Evaluation_CANDIDATE.ipynb').read_text())
        function=None
        for cell in notebook['cells']:
            if cell['cell_type']=='code':
                for node in ast.parse(''.join(cell['source'])).body:
                    if isinstance(node,ast.FunctionDef) and node.name=='canonical_header':function=node
        context={'np':np,'nib':nib,'math':math,'Path':Path,'lru_cache':lru_cache}
        exec(compile(ast.Module(body=[function],type_ignores=[]),'header','exec'),context)
        affines=[np.diag([-1.,2.,3.,1.]),np.array([[0,0,-2,4],[0,3,0,-2],[-4,0,0,8],[0,0,0,1.]]),np.array([[.8,-.4,0,1],[.6,.9,0,2],[0,0,2,3],[0,0,0,1.]])]
        with tempfile.TemporaryDirectory() as root:
            for index,affine in enumerate(affines):
                path=Path(root)/f'orientation-{index}.nii'
                nib.save(nib.Nifti1Image(np.ones((4,5,6),dtype=np.float32),affine),path)
                original=nib.as_closest_canonical(nib.load(path));candidate=context['canonical_header'](str(path))
                np.testing.assert_array_equal(candidate.affine,original.affine)
                self.assertEqual(candidate.shape,original.shape)

if __name__=='__main__':unittest.main()
