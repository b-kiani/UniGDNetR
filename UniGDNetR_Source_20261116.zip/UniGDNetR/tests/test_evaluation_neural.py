"""CPU neural equivalence checks; CUDA/real-cohort approval is a separate gate."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import random
import sys
import tempfile
from types import SimpleNamespace
from typing import *
import unittest
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
if os.environ.get('UNIGDNETR_TORCH_PATH'):sys.path.insert(0,os.environ['UNIGDNETR_TORCH_PATH'])
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except ImportError:
    torch=None

def module(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'scripts'/f'{name}.py')
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
buffers=module('evaluation_buffers');cache_module=module('evaluation_case_cache')
SPECS={'brats':{'modalities':4,'classes':5},'lits':{'modalities':1,'classes':3},'acdc':{'modalities':1,'classes':4}}
def notebook(name):return json.loads((ROOT/'notebooks'/name).read_text())
def functions(nb,names,namespace):
    for cell in nb['cells']:
        if cell['cell_type']=='code':
            for node in ast.parse(''.join(cell['source'])).body:
                if isinstance(node,ast.FunctionDef) and node.name in names:
                    exec(compile(ast.Module(body=[node],type_ignores=[]),'extracted','exec'),namespace)

@unittest.skipIf(torch is None,'Install PyTorch to run neural equivalence checks')
class NeuralTests(unittest.TestCase):
    def setUp(self):
        self.python_rng=random.getstate();self.numpy_rng=np.random.get_state();self.torch_rng=torch.get_rng_state();self.threads=torch.get_num_threads()
        torch.set_num_threads(2)
    def tearDown(self):
        random.setstate(self.python_rng);np.random.set_state(self.numpy_rng);torch.set_rng_state(self.torch_rng);torch.set_num_threads(self.threads)
    def namespace(self):
        ns=dict(globals());ns.update(CFG=SimpleNamespace(context_slices=3,image_size=32,batch_size=2),TASK_SPECS=SPECS,DEVICE=torch.device('cpu'),DiskPrediction=buffers.DiskPrediction)
        return ns
    def test_volume_inference_matches_original_for_tasks_mc_and_scenarios(self):
        original=notebook('03_UniGDNetR_EVALUATE_original.ipynb');candidate=notebook('UniGDNetR_Kaggle_Evaluation_CANDIDATE.ipynb')
        reference=self.namespace();adapted=self.namespace()
        exec(''.join(original['cells'][21]['source']),reference)
        selected={'prepare_inference_slice','apply_corruption','set_mc_dropout','predict_volume'}
        functions(original,selected,reference);functions(candidate,selected,adapted)
        torch.manual_seed(71);net=reference['UniGDNetR'](SPECS,24,48,.1).eval()
        generator=np.random.default_rng(42)
        for task,specification in SPECS.items():
            volume=generator.normal(size=(specification['modalities'],19,23,5)).astype(np.float32)
            mask=generator.integers(0,specification['classes'],(19,23,5),dtype=np.int16)
            reference['load_case']=lambda record:(volume,mask)
            adapted['load_case']=lambda record:(volume,mask)
            cases=[(1,None,('clean',0.)),(8,None,('clean',0.))]
            cases += [(2,None,scenario) for scenario in [('gaussian_noise',.1),('blur',3),('resolution',.5),('gamma',.7)]]
            if task=='brats':cases += [(8,[1],('clean',0.)),(8,[0,2,3],('clean',0.))]
            for samples,missing,corruption in cases:
                with self.subTest(task=task,samples=samples,missing=missing,corruption=corruption):
                    torch.manual_seed(37);random.seed(37);np.random.seed(37)
                    pred,probs,entropy,gt=reference['predict_volume'](net,{'task':task},1.3,samples,missing,corruption)
                    original_rng=torch.get_rng_state().clone()
                    torch.manual_seed(37);random.seed(37);np.random.seed(37)
                    store,candidate_gt=adapted['predict_volume'](net,{'task':task},1.3,samples,missing,corruption)
                    with store:
                        np.testing.assert_array_equal(store.probs,probs)
                        np.testing.assert_array_equal(store.entropy,entropy)
                        np.testing.assert_array_equal(store.pred,pred)
                        np.testing.assert_array_equal(candidate_gt,gt)
                    self.assertTrue(torch.equal(original_rng,torch.get_rng_state()))

    def test_cpu_dropout_case_resume_matches_uninterrupted_and_rng_state(self):
        original=notebook('03_UniGDNetR_EVALUATE_original.ipynb');ns=self.namespace()
        functions(original,{'_rng_state','_restore_rng_state','set_mc_dropout'},ns)
        ns.update(CaseResultCache=cache_module.CaseResultCache,pack_rng=cache_module.pack_rng,unpack_rng=cache_module.unpack_rng)
        def case_result(model,records,*args):
            ns['set_mc_dropout'](model,True)
            score=float((model(torch.ones(20))+torch.randn(20)).sum())+random.random()+np.random.random()
            ns['set_mc_dropout'](model,False)
            return pd.DataFrame([{'case_id':records[0]['case_id'],'score':score,'absent':float('nan')}])
        ns['evaluate_records']=case_result
        exec((ROOT/'scripts/evaluation_case_runtime.py').read_text(),ns)
        model=nn.Sequential(nn.Dropout(.4));records=[{'case_id':str(i)} for i in range(4)]
        def reset():random.seed(13);np.random.seed(13);torch.manual_seed(13)
        with tempfile.TemporaryDirectory() as root:
            ns['OUTPUT_ROOT']=Path(root)/'uninterrupted';ns['check_session_budget']=lambda:None
            reset();expected=ns['evaluate_records'](model,records,'acdc','synthetic',13,case_cache_key='fixed-job')
            expected_torch_rng=torch.get_rng_state().clone()
            ns['OUTPUT_ROOT']=Path(root)/'interrupted';calls=[]
            def pause():
                calls.append(1)
                if len(calls)>2:raise RuntimeError('synthetic budget pause')
            ns['check_session_budget']=pause;reset()
            with self.assertRaisesRegex(RuntimeError,'synthetic budget'):ns['evaluate_records'](model,records,'acdc','synthetic',13,case_cache_key='fixed-job')
            ns['check_session_budget']=lambda:None;reset()
            resumed=ns['evaluate_records'](model,records,'acdc','synthetic',13,case_cache_key='fixed-job')
            np.testing.assert_array_equal(resumed['score'],expected['score'])
            self.assertTrue(torch.equal(expected_torch_rng,torch.get_rng_state()))
if __name__=='__main__':unittest.main()
