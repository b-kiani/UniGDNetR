import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
class ExportTests(unittest.TestCase):
    def test_only_reports_exported_without_rng_caches_or_credentials(self):
        with tempfile.TemporaryDirectory() as temporary:
            base=Path(temporary);project=base/'project';(project/'scripts').mkdir(parents=True)
            shutil.copy2(ROOT/'scripts/sync_results.py',project/'scripts/sync_results.py')
            output=base/'output';(output/'manifests').mkdir(parents=True)
            (output/'manifests/unigdnetr_kaggle_session.json').write_text('{"state":"paused"}')
            files={'results/clean_summary.csv':'dice\n0.5\n','tables/task_summary.csv':'task\nbrats\n',
                   'results/evaluation_case_cache/packet.json':'{"rng":"private"}',
                   'results/evaluation_cache/repeated_metrics.csv':'duplicate\n1\n',
                   'results/recovery_locks/lock.json':'{"pid":1}',
                   'results/credentials.json':'{"placeholder":"must-not-export"}'}
            for relative,text in files.items():
                p=output/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
            result=subprocess.run([sys.executable,str(project/'scripts/sync_results.py'),str(output)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            exported=project/'results'
            manifest=json.loads((exported/'export_manifest.json').read_text())
            self.assertEqual({row['path'] for row in manifest['files']},{'results/clean_summary.csv','tables/task_summary.csv','manifests/unigdnetr_kaggle_session.json'})
            self.assertEqual(len(list(exported.rglob('*.json'))),2)
if __name__=='__main__':unittest.main()
