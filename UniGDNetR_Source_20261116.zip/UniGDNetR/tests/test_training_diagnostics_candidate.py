import ast
import json
import unittest
from pathlib import Path
import torch
import torch.nn.functional as F
from scripts.training_diagnostics_candidate import (
    fp32_soft_dice_candidate, class_counts, summarise_counts,
)


class CandidateChecks(unittest.TestCase):
    def test_fp16_large_foreground_against_original_fp32(self):
        notebook = json.loads((Path(__file__).resolve().parents[1] /
                              'notebooks/02_UniGDNetR_TRAIN_RAM_Fixed.ipynb').read_text())
        source = ''.join(notebook['cells'][23]['source'])
        function = next(n for n in ast.parse(source).body
                        if isinstance(n, ast.FunctionDef) and n.name == 'soft_dice_loss')
        namespace = {'torch': torch, 'F': F}
        exec(compile(ast.Module(body=[function], type_ignores=[]), '<original-loss>', 'exec'), namespace)
        logits = torch.full((2, 5, 256, 256), -8., dtype=torch.float16)
        logits[:, 1] = 8.
        logits.requires_grad_()
        target = torch.ones((2, 256, 256), dtype=torch.long)
        original_half = namespace['soft_dice_loss'](logits, target)
        reference = namespace['soft_dice_loss'](logits.float(), target)
        candidate = fp32_soft_dice_candidate(logits, target)
        self.assertGreater(float(original_half.detach()), .99)
        torch.testing.assert_close(candidate, reference, rtol=0, atol=0)
        self.assertLess(float(candidate.detach()), 1e-5)
        for labels in (target, torch.zeros_like(target)):
            torch.testing.assert_close(
                fp32_soft_dice_candidate(logits.float(), labels),
                namespace['soft_dice_loss'](logits.float(), labels), rtol=0, atol=0)
        candidate.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())

    def test_exact_confusion_and_absence(self):
        # GT 0,1,1,2; prediction 1,1,0,0: class1 TP1 FP1 FN1, class2 missed.
        target = torch.tensor([[[0, 1], [1, 2]]])
        prediction = torch.tensor([[[1, 1], [0, 0]]])
        logits = F.one_hot(prediction, 4).permute(0, 3, 1, 2).float()
        rows = summarise_counts(class_counts(logits, target))
        self.assertEqual(rows[0]['dice'], .5)
        self.assertEqual(rows[0]['false_positive'], 1)
        self.assertEqual(rows[0]['false_negative'], 1)
        self.assertEqual(rows[1]['dice'], 0)
        self.assertIsNone(rows[1]['precision'])
        self.assertIsNone(rows[2]['dice'])

    def test_invalid_inputs_rejected(self):
        logits = torch.zeros(1, 3, 2, 2)
        with self.assertRaises(ValueError):
            fp32_soft_dice_candidate(logits, torch.full((1, 2, 2), 3, dtype=torch.long))
        logits[0, 0, 0, 0] = float('nan')
        with self.assertRaises(ValueError):
            class_counts(logits, torch.zeros(1, 2, 2, dtype=torch.long))
        with self.assertRaises(ValueError):
            summarise_counts([[0, -.1], [0, 1]])


if __name__ == '__main__':
    unittest.main()
